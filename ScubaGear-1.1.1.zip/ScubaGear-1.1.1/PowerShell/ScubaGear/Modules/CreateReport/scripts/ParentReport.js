window.addEventListener('DOMContentLoaded', (event) => {
    mountDarkMode("Parent Report");
});