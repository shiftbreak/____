The baselines have been moved into the ScubaGear PowerShell module for easier distribution. The baselines can now be found [here](../PowerShell/ScubaGear/baselines).  Individual baselines can be visited directly at the links below:

- [Microsoft Entra ID](../PowerShell/ScubaGear/baselines/aad.md)
- [Defender](../PowerShell/ScubaGear/baselines/defender.md)
- [Exchange Online](../PowerShell/ScubaGear/baselines/exo.md)
- [Power BI](../PowerShell/ScubaGear/baselines/powerbi.md)
- [Power Platform](../PowerShell/ScubaGear/baselines/powerplatform.md)
- [SharePoint & OneDrive](../PowerShell/ScubaGear/baselines/sharepoint.md)
- [Teams](../PowerShell/ScubaGear/baselines/teams.md)
